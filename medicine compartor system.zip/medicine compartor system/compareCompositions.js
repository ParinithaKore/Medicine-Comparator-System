const mysql = require('mysql');

// Create a connection to MySQL
const connection = mysql.createConnection({
  host: 'LAPTOP-9Q2RSBU6',
  user: 'root',
  password: 'deepak',
  database: 'pharmacy'
});

// Connect to MySQL
connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL: ', err);
    return;
  }
  console.log('Connected to MySQL');
  
  // Specify the composition to compare
  const compositionToCompare = 'composition_value';
  
  // Execute SQL query to compare compositions
  const sql = 'SELECT * FROM ,Med, WHERE, Composition = ?' ;
  connection.query(sql, [compositionToCompare], (err, results) => {
    if (err) {
      console.error('Error executing query: ', err);
      return;
    }

    // Display result
    results.forEach((row) => {
      console.log('Tablet Name:', row.Tablet_Name);
      console.log('Brand:', row.Brand);
      console.log('Composition:', row.Composition);
      console.log('Side Effects:', row.Side_effects);
      console.log('Purpose:', row.Purpose);
      console.log('Cost:', row.Cost);
      console.log();
    });
    
    // Close connection
    connection.end();
  });
});