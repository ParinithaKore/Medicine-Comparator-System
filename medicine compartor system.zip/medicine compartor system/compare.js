const express = require('express');
const mysql = require('mysql');

const app = express();
const port = 3000;

// MySQL Connection Configuration
const dbConfig = {
  host: 'LAPTOP-9Q2RSBU6',
  user: 'root',
  password: 'deepak',
  database: 'pharmacy'
};

// Create a MySQL pool
const pool = mysql.createPool(dbConfig);

// Search endpoint
app.get('/search', (req, res) => {
  const composition = req.query.composition;

  // Query to search for matching rows
  const query = `SELECT * FROM Med WHERE Composition = ?`;

  // Execute the query
  pool.query(query, [composition], (error, results) => {
    if (error) {
      console.error('Error executing query:', error);
      res.status(500).send('Internal Server Error');
      return;
    }

    // Send the results back to the client
    res.json(results);
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
